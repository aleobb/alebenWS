#include <stdio.h>
#include <stdlib.h>

#define AREA_COMPRAS    0
#define AREA_VENTAS     1

#define TYPE_PROGRAMADOR    1
#define TYPE_ADMINISTRATIVO 2


struct S_Object
{
    int type;
};
typedef struct S_Object Object;


struct S_Administrativo
{
    Object obj;
    char nombre[20];
    int area; // AREA_COMPRAS, AREA_VENTAS
};
typedef struct S_Administrativo Administrativo;

struct S_Programador
{
    Object obj;
    char nombre[20];
    char lenguaje[16]; // "C", "JAVA", "PYTHON"
};
typedef struct S_Programador Programador;

void imprimirObject(Object* o);


int main()
{
    Programador p;
    p.obj.type=TYPE_PROGRAMADOR;
    sprintf(p.nombre,"juan");
    sprintf(p.lenguaje,"JAVA");

    Administrativo a;
    a.obj.type = TYPE_ADMINISTRATIVO;
    sprintf(a.nombre,"pepe");
    a.area = AREA_VENTAS;

    Object* o1;
    Object* o2;
    o1 = (Object*)&p;
    o2 = (Object*)&a;

    imprimirObject(o1);
    imprimirObject(o2);


    return 0;
}


void imprimirObject(Object* o)
{
    Programador* p;
    Administrativo* a;

    switch(o->type)
    {
        case TYPE_PROGRAMADOR:
            p = (Programador*) o;
            printf("PROGRAMADOR. Nombre:%s. Lenguaje:%s\r\n",p->nombre,p->lenguaje);
            break;

        case TYPE_ADMINISTRATIVO:
            a = (Administrativo*) o;
            printf("ADMINISTRATIVO. Nombre:%s. Area:%d\r\n",a->nombre,a->area);
            break;
    }

}
