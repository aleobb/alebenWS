// int calcIndiceV(int vector[], int sizeVector, int minMax); // calcula indice minimo y maximo
// int expandirCompactarV(int vector[], int sizeVector, int indice, int compExp);
// void ordenarV(int vector[],int sizeVector, int vectorRdo[], int menorMayor);
