


void listarUsuariosConCalificaciones(EUsuario* arrayUsuarios, int sizeArrayUsuarios);

void listarUsuarios(EUsuario* arrayUsuarios, int sizeArrayUsuarios);

void listarPublicacionesUsuarioPorId(EUsuario* arrayUsuarios, int sizeArrayUsuarios, EProducto* arrayProductos, int sizeArrayProductos);

int listarProductosUsuario(EProducto* arrayProductos, int sizeArrayProductos, int idUsuario);

void listarProductos(EProducto* arrayProductos, int sizeArrayProductos);

void listarProductosConNombreUsuario(EProducto* arrayProductos, int sizeArrayProductos, EUsuario* arrayUsuarios, int sizeArrayUsuarios);



