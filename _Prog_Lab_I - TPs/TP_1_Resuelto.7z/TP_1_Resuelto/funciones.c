#include <stdio.h>
#include <stdlib.h>

void infDatosIng(int flagA, int flagB, int option)
{
    if ( option>2 && (flagA + flagB)<2  )
    {
        printf("\n Atencion!! No se puede realizar una niguna operacion ");
        if (flagA == 1)
            { printf("\n (salvo factorial) porque falta ingresar el valor del 2do operando. \n "); }
        else if (flagB == 1)
            { printf("\n porque falta ingresar el valor del 1er operando. \n"); }
        else
            { printf("\n porque todavia no ha ingresado el valor de ningun operando. \n"); }
    }
}


float suma(float A, float B)
{
    return (A+B);
}

float resta(float A, float B)
{
    return (A-B);
}

float division(float A, float B)
{
    if ( B == 0 )
    {
        printf("\n El divisor es igual a 0 y por tanto no puede realizarse la division. Modifiquelo e intente nuevamente. \n\n");
        return 0;
    }
    else
        { return (A/B); }
}

double multiplicacion(float A, float B)
{
    return (A*B);
}

double factorial(double A)
{
    double factA=1;
    double aux;
    if ( A < 0 )
    {
        printf("\n El valor factorial no puede calcularse debido a que el 1er operando no es un entero o es un numero negativo.\nModifiquelo e intente nuevamente. \n\n");
        return 0;
    }
    else
    {
        for (aux = A; aux > 1; aux--)
            { factA = factA * aux; }
        return factA;
    }
}
