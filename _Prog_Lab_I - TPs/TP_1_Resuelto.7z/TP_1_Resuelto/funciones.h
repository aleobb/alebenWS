#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

void infDatosIng(int flagA, int flagB, int option);

float suma(float A, float B);
float resta(float A, float B);
float division(float A, float B);
double multiplicacion(float A, float B);
double factorial(double A);



#endif // FUNCIONES_H_INCLUDED
