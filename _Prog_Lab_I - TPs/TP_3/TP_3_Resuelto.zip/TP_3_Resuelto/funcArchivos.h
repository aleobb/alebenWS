

int abrirArchBinModoLectura(FILE* pFile, char paramArch[]);

int abrirArchBinModoEscritura(FILE* pFile, char paramArch[]);

int abrirArchBinModoAppend(FILE* pFile, char paramArch[]);

int cerrarArch(FILE* pFile);
