#include <Arduino.h>
//#include <LiquidCrystal.h>
//#include "reloj.h"
#include "timer.h"

#define TIMER 0
#define MILLIS 200

#define FALSE 0
#define TRUE 1


/// Aclaraciones respecto de los define de las luces leds:
/// Las letras R, A, V representan los Leds Rojo, Amarillo y Verde respectivamente.
/// El agregado P indican que esos leds corresponden al semaforo peatonal
/// El agregado del numero indican que corresponden a los leds del semaforo principal(1) o secundario(2) (tanto vehicular como peatonal)

/// Luces Semaforo Principal:
#define R1 10
#define A1 11
#define V1 12
/// Luces Semaforo Peatonal Principal:
#define RP1 8
#define VP1 9

/// Luces Semaforo Secundario:
#define R2 4
#define A2 5
#define V2 6
/// Luces Semaforo Peatonal Secundario:
#define RP2 2
#define VP2 3

/// Boton de demanda de cruce peatonal:
#define BOTON1 0   // Semaforo Secundario
#define BOTON2 13  // Semaforo Principal
/// Sensor de vehiculo en calle secundaria:
#define SENSOR 1

#define SEMAFOROSQTY 2  /// Cantidad total de semaforos
#define LEDSQTY 5       /// Cantidad total de luces led por semaforo
#define STATUSQTY 5     /// Cantidad total de diferentes estados para cada semaforo
#define SECUENCEQTY 8   /// Cantidad total de secuencias por ciclo de estados
#define SECUENCEPARTS 2 /// Cantidad de partes de la secuencia


/// Prototipos de funciones a utilizar:
void initSemaforo();
void setStatus(int secNumber);


/// Se define arrayEstructura de uso global con los estados de los leds de los semaforos
int pinLedSemaforo[SEMAFOROSQTY][LEDSQTY] = { {R1,A1,V1,RP1,VP1} , {R2,A2,V2,RP2,VP2} };
S_Secuencia secuence[SECUENCEQTY];

int iniciarSecuencia = FALSE;
int secuenceNumber = 0;


void semaforo_setup()
{
    int i, j;
    /// Se inicializan los PINES correspondientes a todos los leds como salida digital:
    for (j = 0; j < SEMAFOROSQTY ; j++)
        for (i = 0; i < LEDSQTY ; i++)
            pinMode(pinLedSemaforo[j][i], OUTPUT);

    initSemaforo(); /// Cargo los datos del ciclo de estados de los semaforos y los seteo a su estado por defecto

    /// Se inicializan los PINES correspondientes a los botones y sensor como entrada digital:
    pinMode(BOTON1, INPUT);
    pinMode(BOTON2, INPUT);
    pinMode(SENSOR, INPUT);
}

void semaforo_loop()
{
    if ( iniciarSecuencia == TRUE )
    {
        if ( secuenceNumber == SECUENCEQTY*SECUENCEPARTS )
        //if ( secuenceNumber == CICLESECUENCEQTY )  /// si ya se cumpli� un ciclo entero reinicio el contador de secuencia y el estado a iniciarSecuencia=FALSE
        {
            secuenceNumber = 0;
            iniciarSecuencia = FALSE;
        }
        else if ( timer_waitMs(TIMER, MILLIS) ) /// Si el reloj lleg� a cero entra, incrementa el contador de secuencia y reinicia el reloj
        {
            secuenceNumber++;
            timer_waitMs(TIMER, MILLIS);
        }
        setStatus(secuenceNumber);
    }
    else if ( digitalRead(BOTON2) == 0 || digitalRead(SENSOR) == 0  )
    {
        timer_waitMs(TIMER, MILLIS); /// Inicio el Timer
        iniciarSecuencia = TRUE; /// Inicio la secuencia
        secuenceNumber++; /// Incremento el nro de la secuencia de estados del Semaforo
    }
}


void initSemaforo()
{
    int states[STATUSQTY][LEDSQTY] = { {0,0,1,1,0} , {0,0,0,1,0} , {0,1,0,1,0} , {1,0,0,0,1} , {1,0,0,0,0} };
    int stateTime[SECUENCEQTY] = {5,1,1,1,1,1,1,1};
    int stateIndex[SEMAFOROSQTY][SECUENCEQTY] = { {0,1,0,1,0,2,2,2} , {3,3,3,4,3,4,3,4} }; /// {1er secuencia de estados para el semaforo 1 (2da para el 2)} {2da secuencia de estados para el semaforo 1 (1era para el 2)}

    int i, j, k;
    for (k = 0; k < SECUENCEQTY ; k++)
    {
        (secuence+k)->time = stateTime[k];
        for (j = 0; j < SEMAFOROSQTY ; j++)
            for (i = 0; i < LEDSQTY ; i++)
                (secuence+k)->state[j][i] = states[ stateIndex[j][k] ][i];
    }
    setStatus(0); /// Establezco el estado de los leds de los semaforos a su estado por defecto
}


void setStatus(int secNumber) /// Deber�a controlar que no pase de
{
    int i, j, k;
    for (j=0, k=SEMAFOROSQTY-1; j < SEMAFOROSQTY ; j++,k--)
    {
        for (i = 0; i < LEDSQTY ; i++)
        {
            if ( secNumber < SECUENCEQTY )
                digitalWrite( pinLedSemaforo[j][i] , (secuence+secNumber)->state[j][i] );
            else
                digitalWrite( pinLedSemaforo[j][i] , (secuence+secNumber-SECUENCEQTY)->state[k][i] );
        }
    }
        /// ��� digitalWrite( (semaforo+j)->ledPin[i], (semaforo+j)->*(ledState+stateSecuence)->Number[j][i])[i] ); ???
}

