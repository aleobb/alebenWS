void reloj_setup(void);
void reloj_loop(void);
int read_LCD_buttons(void);
void incrementarSegundos();
